/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.io.*;

public class FileEncryptionDecryption {

    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.println("Enter 'E' for encryption or 'D' for decryption:");
            char choice = reader.readLine().toUpperCase().charAt(0);

            if (choice == 'E') {
                System.out.println("Enter the name or path of the file to encrypt:");
                String inputFile = reader.readLine();
                System.out.println("Enter the name of the encrypted file:");
                String outputFile = reader.readLine();
                encryptFile(inputFile, outputFile);
                System.out.println("File encrypted successfully.");
            } else if (choice == 'D') {
                System.out.println("Enter the name or path of the file to decrypt:");
                String inputFile = reader.readLine();
                System.out.println("Enter the name of the decrypted file:");
                String outputFile = reader.readLine();
                decryptFile(inputFile, outputFile);
                System.out.println("File decrypted successfully.");
            } else {
                System.out.println("Invalid choice. Please enter 'E' for encryption or 'D' for decryption.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void encryptFile(String inputFile, String outputFile) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            int ch;
            while ((ch = reader.read()) != -1) {
                ch = ch + 3; // Shift characters by 3 positions
                writer.write(ch);
            }
        }
    }

    public static void decryptFile(String inputFile, String outputFile) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            int ch;
            while ((ch = reader.read()) != -1) {
                ch = ch - 3; // Shift characters back by 3 positions
                writer.write(ch);
            }
        }
    }
}

