/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;

public class PasswordStrengthChecker {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your password:");
        String password = scanner.nextLine();

        int length = password.length();
        boolean hasUpperCase = false;
        boolean hasLowerCase = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;

        for (int i = 0; i < length; i++) {
            char ch = password.charAt(i);
            if (Character.isUpperCase(ch)) {
                hasUpperCase = true;
            } else if (Character.isLowerCase(ch)) {
                hasLowerCase = true;
            } else if (Character.isDigit(ch)) {
                hasDigit = true;
            } else {
                hasSpecialChar = true;
            }
        }

        // Analyze password strength
        int strength = 0;
        if (length >= 8) {
            strength++;
        }
        if (hasUpperCase) {
            strength++;
        }
        if (hasLowerCase) {
            strength++;
        }
        if (hasDigit) {
            strength++;
        }
        if (hasSpecialChar) {
            strength++;
        }

        // Provide feedback on password strength
        System.out.print("Password strength: ");
        switch (strength) {
            case 0:
                System.out.println("Very Weak");
                break;
            case 1:
                System.out.println("Weak");
                break;
            case 2:
                System.out.println("Moderate");
                break;
            case 3:
                System.out.println("Strong");
                break;
            case 4:
                System.out.println("Very Strong");
                break;
            case 5:
                System.out.println("Extremely Strong");
                break;
            default:
                break;
        }
    }
}
