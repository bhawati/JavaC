/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class CalculatorApp extends Application {

    private String currentNumber = "";
    private String previousOperation = "";
    private double result = 0;

    @Override
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setVgap(5);
        gridPane.setHgap(5);

        Text output = new Text();
        output.setStyle("-fx-font-size: 20px;");
        GridPane.setColumnSpan(output, 4);
        gridPane.add(output, 0, 0);

        Button[] buttons = new Button[]{
                new Button("7"), new Button("8"), new Button("9"), new Button("/"),
                new Button("4"), new Button("5"), new Button("6"), new Button("*"),
                new Button("1"), new Button("2"), new Button("3"), new Button("-"),
                new Button("C"), new Button("0"), new Button("="), new Button("+")
        };

        for (int i = 0; i < buttons.length; i++) {
            int row = i / 4 + 1;
            int col = i % 4;
            buttons[i].setPrefSize(50, 50);
            gridPane.add(buttons[i], col, row);
        }

        for (Button button : buttons) {
            button.setOnAction(e -> {
                String buttonText = button.getText();
                if (buttonText.matches("[0-9]")) {
                    currentNumber += buttonText;
                    output.setText(currentNumber);
                } else if (buttonText.equals("C")) {
                    currentNumber = "";
                    result = 0;
                    output.setText("");
                } else if (buttonText.matches("[+\\-*/]")) {
                    if (!currentNumber.isEmpty()) {
                        double num = Double.parseDouble(currentNumber);
                        switch (previousOperation) {
                            case "+":
                                result += num;
                                break;
                            case "-":
                                result -= num;
                                break;
                            case "*":
                                result *= num;
                                break;
                            case "/":
                                if (num != 0)
                                    result /= num;
                                else
                                    output.setText("Error");
                                break;
                            default:
                                result = num;
                                break;
                        }
                        currentNumber = "";
                        output.setText("");
                        previousOperation = buttonText;
                    }
                } else if (buttonText.equals("=")) {
                    if (!currentNumber.isEmpty()) {
                        double num = Double.parseDouble(currentNumber);
                        switch (previousOperation) {
                            case "+":
                                result += num;
                                break;
                            case "-":
                                result -= num;
                                break;
                            case "*":
                                result *= num;
                                break;
                            case "/":
                                if (num != 0)
                                    result /= num;
                                else
                                    output.setText("Error");
                                break;
                            default:
                                result = num;
                                break;
                        }
                        currentNumber = "";
                        output.setText(Double.toString(result));
                    }
                }
            });
        }

        VBox root = new VBox(gridPane);
        Scene scene = new Scene(root);
        primaryStage.setTitle("Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
