/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class MultiThreadedApp {
    private static final int NUM_THREADS = 5;
    private static final int NUM_INCREMENTS = 1000;
    
    private static int counter = 0;

    public static void main(String[] args) {
        // Create and start multiple threads
        Thread[] threads = new Thread[NUM_THREADS];
        for (int i = 0; i < NUM_THREADS; i++) {
            threads[i] = new IncrementThread();
            threads[i].start();
        }

        // Wait for all threads to finish
        for (int i = 0; i < NUM_THREADS; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Print the final value of the counter
        System.out.println("Final Counter Value: " + counter);
    }

    private static class IncrementThread extends Thread {
        @Override
        public void run() {
            for (int i = 0; i < NUM_INCREMENTS; i++) {
                // Increment the shared counter in a synchronized block
                synchronized (MultiThreadedApp.class) {
                    counter++;
                }
            }
        }
    }
}
